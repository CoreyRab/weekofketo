export default {
  "trailingSlash": true,
  "pathPrefix": "",
  "titleTemplate": "%s - Week of Keto",
  "siteUrl": "https://youthful-sinoussi-3b94da.netlify.com",
  "version": "0.7.12"
}