import plugin_gridsome_plugin_google_analytics_7 from "/Users/filipstepien/Development/tutorials/week-of-keto/node_modules/@gridsome/plugin-google-analytics/gridsome.client.js"
import plugin_gridsome_plugin_gtm_8 from "/Users/filipstepien/Development/tutorials/week-of-keto/node_modules/gridsome-plugin-gtm/gridsome.client.js"

export default [
  {
    run: plugin_gridsome_plugin_google_analytics_7,
    options: {}
  },
  {
    run: plugin_gridsome_plugin_gtm_8,
    options: {"enabled":true}
  }
]
