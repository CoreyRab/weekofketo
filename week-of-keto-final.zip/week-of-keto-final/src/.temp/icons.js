export default {
  "touchiconMimeType": "image/png",
  "faviconMimeType": "image/png",
  "precomposed": false,
  "touchicons": [],
  "favicons": [
    {
      "width": 16,
      "src": "/assets/static/src/favicon.png?width=16&key=01823c5"
    },
    {
      "width": 32,
      "src": "/assets/static/src/favicon.png?width=32&key=01823c5"
    }
  ]
}