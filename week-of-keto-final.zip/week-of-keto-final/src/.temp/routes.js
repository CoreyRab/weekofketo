export default [
  {
    path: "/issues/37/",
    component: () => import(/* webpackChunkName: "page--src--templates--issue-view-vue" */ "/Users/filipstepien/Development/tutorials/week-of-keto/src/templates/IssueView.vue")
  },
  {
    path: "/issues/",
    component: () => import(/* webpackChunkName: "page--src--pages--issues-vue" */ "/Users/filipstepien/Development/tutorials/week-of-keto/src/pages/Issues.vue")
  },
  {
    name: "404",
    path: "/404/",
    component: () => import(/* webpackChunkName: "page--node-modules--gridsome--app--pages--404-vue" */ "/Users/filipstepien/Development/tutorials/week-of-keto/node_modules/gridsome/app/pages/404.vue")
  },
  {
    name: "home",
    path: "/",
    component: () => import(/* webpackChunkName: "page--src--pages--index-vue" */ "/Users/filipstepien/Development/tutorials/week-of-keto/src/pages/Index.vue")
  },
  {
    name: "*",
    path: "*",
    component: () => import(/* webpackChunkName: "page--node-modules--gridsome--app--pages--404-vue" */ "/Users/filipstepien/Development/tutorials/week-of-keto/node_modules/gridsome/app/pages/404.vue")
  }
]

